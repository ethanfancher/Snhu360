package com.example.weight_app_3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.Toast;

import java.util.List;

public class history extends AppCompatActivity {
    private TextView mDate;
    private TextView mWeight;
    private TextView editDate;
    private TextView editWeight;
    private weight_app_database mDatabase;
    private Switch mSwitch;
    private Switch mSwitch2;
    private Switch mSwitch3;
    private Switch mSwitch4;
    private Switch mSwitch5;
    private Switch mSwitch6;
    private Switch mSwitch7;
    private Switch mSwitch8;
    private Switch mSwitch9;
    private Switch mSwitch10;
    private TextView editDateTemp;
    private TextView editWeightTemp;
    private List<DailyWeight> mListWeights;
    private List<DailyWeight> mTempList;
    private DailyWeight mDailyWeight;
    private weight_item mWeightItem;
    private Button mLoadMore;
    private Button mReset;
    private Button mDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        //openTitleBar(new title_bar());
        mDatabase = weight_app_database.getInstance(getApplicationContext());
        mDate = findViewById(R.id.weight_history_date);
        mWeight = findViewById(R.id.weight_history_value);
        mSwitch = findViewById(R.id.switch1);
        mSwitch2 = findViewById(R.id.switch2);
        mSwitch3 = findViewById(R.id.switch3);
        mSwitch4 = findViewById(R.id.switch4);
        mSwitch5 = findViewById(R.id.switch5);
        mSwitch6 = findViewById(R.id.switch6);
        mSwitch7 = findViewById(R.id.switch7);
        mSwitch8 = findViewById(R.id.switch8);
        mSwitch9 = findViewById(R.id.switch9);
        //mSwitch10 = findViewById(R.id.switch10);
        mListWeights = mDatabase.getDailyWeights();
        mTempList = mListWeights;
        mLoadMore = findViewById(R.id.load_more_button);
        mReset = findViewById(R.id.reset_button);
        mDelete = findViewById(R.id.delete_button);
        Fragment weightItem = new weight_item();
        if (mListWeights.size() > 0) {
            loadMultiples(mListWeights.size());
        }
    }
    // creates fragments for the list items
    void loadMultiples(int count) {
        if (count > 9) {
            mLoadMore.setEnabled(true);
            mReset.setEnabled(true);
        }
        for (int i = 0; i < count; i++) {
            FragmentTransaction insertFragment = getSupportFragmentManager().beginTransaction();
            mDailyWeight = mTempList.get(i);
            //mDailyWeight = mTempList.get(i);
            if (i == 0) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight1);
                editDateTemp = findViewById(R.id.date1);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch.setEnabled(true);
            }
            else if (i == 1) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight2);
                editDateTemp = findViewById(R.id.date2);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch2.setEnabled(true);
            }
            else if (i == 2) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight3);
                editDateTemp = findViewById(R.id.date3);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch3.setEnabled(true);
            }
            else if (i == 3) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight4);
                editDateTemp = findViewById(R.id.date4);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch4.setEnabled(true);
            }
            else if (i == 4) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight5);
                editDateTemp = findViewById(R.id.date5);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch5.setEnabled(true);
            }
            else if (i == 5) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight6);
                editDateTemp = findViewById(R.id.date6);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch6.setEnabled(true);
            }
            else if (i == 6) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight7);
                editDateTemp = findViewById(R.id.date7);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch7.setEnabled(true);
            }
            else if (i == 7) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight8);
                editDateTemp = findViewById(R.id.date8);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch8.setEnabled(true);
            }
            else if (i == 8) {
                String tempString = mDailyWeight.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight9);
                editDateTemp = findViewById(R.id.date9);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mDailyWeight.getDate());
                mSwitch9.setEnabled(true);
            }
        }
    }
    // enables up to 36 lists of 9 items
    public void loadMoreWeights(android.view.View view) {
        List<DailyWeight> subList;
        if (mTempList.get(0) == mListWeights.get(0)) {
            mTempList = mListWeights.subList(9, 17);
        }
        else if (mTempList.get(0) == mListWeights.get(9)) {
            mTempList = mListWeights.subList(18, 26);
        }
        else if (mTempList.get(0) == mListWeights.get(18)) {
            mTempList = mListWeights.subList(27, 35);
        }
    }
    // resets the temp list to the original list, therefore resetting the display to the first 10 items
    public void resetWeights(android.view.View view) {
        mTempList = mListWeights;
    }
    // opens title bar
    void openTitleBar(Fragment title_bar) {
        FragmentTransaction createTitleBar = getSupportFragmentManager().beginTransaction();
        createTitleBar.replace(R.id.title_bar, title_bar);
        createTitleBar.addToBackStack(null);
        createTitleBar.commit();
    }
    // deletes a selected weight item
    public void deleteWeights(android.view.View view) {
        if (mSwitch.isChecked()) {
            Toast.makeText(getApplicationContext(), "Switch 1 checked", Toast.LENGTH_SHORT).show();
            mDailyWeight = mListWeights.get(0);
            mListWeights.remove(0);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch2.isChecked()) {
            mDailyWeight = mListWeights.get(1);
            mListWeights.remove(1);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch3.isChecked()) {
            mDailyWeight = mListWeights.get(2);
            mListWeights.remove(2);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch4.isChecked()) {
            mDailyWeight = mListWeights.get(3);
            mListWeights.remove(3);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch5.isChecked()) {
            mDailyWeight = mListWeights.get(4);
            mListWeights.remove(4);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch6.isChecked()) {
            mDailyWeight = mListWeights.get(5);
            mListWeights.remove(5);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch7.isChecked()) {
            mDailyWeight = mListWeights.get(6);
            mListWeights.remove(6);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch8.isChecked()) {
            mDailyWeight = mListWeights.get(7);
            mListWeights.remove(7);
            mDatabase.deleteDaily(mDailyWeight);
        }
        if (mSwitch9.isChecked()) {
            mDailyWeight = mListWeights.get(8);
            mListWeights.remove(8);
            mDatabase.deleteDaily(mDailyWeight);
        }
        // updates the list used for display after deleting item
        mTempList = mListWeights;
        loadMultiples(mListWeights.size());
    }
    // menu handling
    public void onClickHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void onClickHistory(View view) {
        Intent intent = new Intent(this, history.class);
        startActivity(intent);
    }
    public void onClickAddRecord(View view) {
        Intent intent = new Intent(this, add_record.class);
        startActivity(intent);
    }
    public void onClickWeightGoal(View view) {
        Intent intent = new Intent(this, edit_goal.class);
        startActivity(intent);
    }
    public void onClickSettings(View view) {
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }
}