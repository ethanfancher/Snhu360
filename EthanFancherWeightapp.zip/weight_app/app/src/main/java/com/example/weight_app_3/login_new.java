package com.example.weight_app_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class login_new extends AppCompatActivity {
    private EditText mUser;
    private EditText mPassword;
    private Button mSignInButton;
    private weight_app_database mDatabase;
    public boolean validUser;


    KeyGenerator keyGenerator;
    SecretKey secretKey;
    // ENCRYPTION SOURCE: https://www.amarinfotech.com/how-to-do-aes-256-encryption-decryption-in-android.html
    public SecretKey initializeEncryption() {
        try {
            keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            secretKey = keyGenerator.generateKey();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        byte[] IV = new byte[16];
        SecureRandom random;
        random = new SecureRandom();
        return secretKey;
    }
    public static byte[] encrypt(byte[] plaintext, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
        //IvParameterSpec ivSpec = new IvParameterSpec(IV);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        byte[] cipherText = cipher.doFinal(plaintext);
        return cipherText;
    }
    public static String decrypt(byte[] cipherText, SecretKey key, byte[] IV) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(IV);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] decryptedText = cipher.doFinal(cipherText);
            return new String(decryptedText);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_new);
        mUser = findViewById(R.id.username_input);
        mPassword = findViewById(R.id.password_input);
        mSignInButton = findViewById(R.id.signInButton);
        mDatabase = weight_app_database.getInstance(getApplicationContext());
        validUser = false;

    }
    public boolean validateUser(String username, String password) {
        if (mDatabase.validateUser(username, password) == 1){
            Toast.makeText(getApplicationContext(), "Welcome!", Toast.LENGTH_LONG).show();
            return true;
        }
        else {
            User newUser = new User(username, password);
            boolean userAdd = mDatabase.addUser(newUser);
            if (userAdd) {
                Toast.makeText(getApplicationContext(), "User Was Not in System - Added", Toast.LENGTH_SHORT).show();
                return true;
            }
            else {
                Toast.makeText(getApplicationContext(), "User Was Not in System - Failed to Add", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
    }
    public void test(android.view.View view) {
        //Toast.makeText(getApplicationContext(), "An Error Occurred", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void signIn(android.view.View view) {
        //encryption start of password
        secretKey = initializeEncryption();
        String username = "";
        byte[] password;
        SecureRandom random = new SecureRandom();
        try {
            username = mUser.getText().toString();
            password = mPassword.getText().toString().getBytes();
            password = encrypt(password, secretKey);
            String stringPassword = password.toString();
            //Toast.makeText(getApplicationContext(), stringPassword, Toast.LENGTH_LONG).show();
            if(validateUser(username, stringPassword)) {
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "An Error Occurred", Toast.LENGTH_SHORT).show();
        }
    }
    public boolean getValidUser() {
        return validUser;
    }
}